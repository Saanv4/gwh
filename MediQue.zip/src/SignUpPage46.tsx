import { FunctionComponent } from "react";
import styles from "./css/SignUpPage46.module.css";

export const SignUpPage46: FunctionComponent = () => {
  return (
    <div className={styles.signUpPage4}>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" src="rectangle-10.svg" />
      <div className={styles.rectangleDiv2} />
      <div className={styles.rectangleDiv3} />
      <div className={styles.frequencyOfMedicine2}>
        Frequency of Medicine #2
      </div>
      <div className={styles.ofTotalCapsules}># of Total Capsules</div>
      <b className={styles.loginB}>Login</b>
      <div className={styles.medicine2Div}>Medicine #2</div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <div className={styles.rectangleDiv4} />
      <b className={styles.nextB}>
        <p className={styles.nextP}>Next</p>
      </b>
      <div className={styles.backDiv}>Back</div>
    </div>
  );
};
