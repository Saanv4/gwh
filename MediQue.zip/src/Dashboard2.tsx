import { FunctionComponent, useCallback } from "react";
import { Player } from "@lottiefiles/react-lottie-player";
import { useNavigate } from "react-router-dom";
import styles from "./css/Dashboard2.module.css";

export const Dashboard2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onEllipseClick = useCallback(() => {
    navigate("/calendar");
  }, [navigate]);

  const onImage2LottieClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='ellipse']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onImage3IconClick = useCallback(() => {
    navigate("/medicine-refill");
  }, [navigate]);

  return (
    <div className={styles.dashboard2Div}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <img
        className={styles.ellipseIcon}
        alt=""
        src="ellipse-2.svg"
        onClick={onEllipseClick}
      />
      <img
        className={styles.ellipseIcon1}
        alt=""
        src="ellipse-2.svg"
        data-scroll-to="ellipse"
      />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon4} alt="" src="ellipse-2.svg" />
      <img className={styles.image1Icon} alt="" src="image-1@2x.png" />
      <Player
        className={styles.image2Player}
        autoplay
        src=""
        onClick={onImage2LottieClick}
      />
      <img
        className={styles.image3Icon}
        alt=""
        src="image-3@2x.png"
        onClick={onImage3IconClick}
      />
      <img className={styles.image4Icon} alt="" src="image-4@2x.png" />
      <img className={styles.image5Icon} alt="" src="image-5@2x.png" />
      <div className={styles.welcomeDiv}>
        <p className={styles.welcomeP}>{`Welcome `}</p>
        <p className={styles.p}>{`  `}</p>
      </div>
    </div>
  );
};
