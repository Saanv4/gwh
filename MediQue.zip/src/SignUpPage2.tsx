import { FunctionComponent, useEffect } from "react";
import styles from "./css/SignUpPage2.module.css";

export const SignUpPage2: FunctionComponent = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div className={styles.signUpPage2}>
      <div className={styles.rectangleDiv} />
      <input
        className={styles.rectangleInput}
        type="text"
        required
        data-animate-on-scroll
      />
      <input
        className={styles.rectangleInput1}
        type="text"
        required
        data-animate-on-scroll
      />
      <input
        className={styles.rectangleInput2}
        type="text"
        required
        data-animate-on-scroll
      />
      <div className={styles.genderDiv}>Gender</div>
      <div className={styles.doctorNameDiv}>{`Doctor Name `}</div>
      <div className={styles.doctorPhone}>Doctor Phone #</div>
      <div className={styles.ageDiv}>Age</div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <input className={styles.rectangleInput3} type="text" />
      <b className={styles.nextB}>
        <p className={styles.nextP}>Next</p>
      </b>
      <b className={styles.signUpB}>Sign up</b>
      <img className={styles.userIcon} alt="" src="user.svg" />
      <input
        className={styles.rectangleInput4}
        type="text"
        required
        data-animate-on-scroll
      />
    </div>
  );
};
