import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/Calendar.module.css";

export const Calendar: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.calendarDiv}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <div className={styles.screenshot20220816At1050} />
      <div className={styles.calendarDiv1}>
        <p className={styles.calendarP}>Calendar</p>
        <p className={styles.p}>{`  `}</p>
      </div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.imDoneDiv}>I’m done</div>
      <div className={styles.rectangleDiv2} />
      <img
        className={styles.screenshot20220817At1248}
        alt=""
        src="screenshot-20220817-at-1248-1@2x.png"
      />
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
    </div>
  );
};
