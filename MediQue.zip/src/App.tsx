import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import { SignUpPage1 } from "./SignUpPage1";
import { SignUpPage3 } from "./SignUpPage3";
import { SignUpPage4 } from "./SignUpPage4";
import { SignUpPage41 } from "./SignUpPage41";
import { SignUpPage42 } from "./SignUpPage42";
import { SignUpPage43 } from "./SignUpPage43";
import { SignUpPage31 } from "./SignUpPage31";
import { SignUpPage32 } from "./SignUpPage32";
import { SignUpPage33 } from "./SignUpPage33";
import { SignUpPage34 } from "./SignUpPage34";
import { SignUpPage44 } from "./SignUpPage44";
import { SignUpPage45 } from "./SignUpPage45";
import { SignUpPage35 } from "./SignUpPage35";
import { SignUpPage46 } from "./SignUpPage46";
import { SignUpPage36 } from "./SignUpPage36";
import { Emergency } from "./Emergency";
import { MedicineTracker } from "./MedicineTracker";
import { MedicineRefill } from "./MedicineRefill";
import { MedicineDiary } from "./MedicineDiary";
import { Calendar } from "./Calendar";
import { Dashboard1 } from "./Dashboard1";
import { SignUpPage37 } from "./SignUpPage37";
import { LoginPage1 } from "./LoginPage1";
import { Dashboard2 } from "./Dashboard2";
import { SignUpPage2 } from "./SignUpPage2";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    //TODO: Update meta titles and descriptions below
    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-4":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/emergency":
        title = "";
        metaDescription = "";
        break;
      case "/medicine-tracker":
        title = "";
        metaDescription = "";
        break;
      case "/medicine-refill":
        title = "";
        metaDescription = "";
        break;
      case "/medicine-diary":
        title = "";
        metaDescription = "";
        break;
      case "/calendar":
        title = "";
        metaDescription = "";
        break;
      case "/dashboard-1":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-3":
        title = "";
        metaDescription = "";
        break;
      case "/login-page-1":
        title = "";
        metaDescription = "";
        break;
      case "/dashboard-2":
        title = "";
        metaDescription = "";
        break;
      case "/sign-up-page-2":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<SignUpPage1 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage3 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage4 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage41 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage42 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage43 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage31 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage32 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage33 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage34 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage44 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage45 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage35 />} />

      <Route path="/sign-up-page-4" element={<SignUpPage46 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage36 />} />

      <Route path="/emergency" element={<Emergency />} />

      <Route path="/medicine-tracker" element={<MedicineTracker />} />

      <Route path="/medicine-refill" element={<MedicineRefill />} />

      <Route path="/medicine-diary" element={<MedicineDiary />} />

      <Route path="/calendar" element={<Calendar />} />

      <Route path="/dashboard-1" element={<Dashboard1 />} />

      <Route path="/sign-up-page-3" element={<SignUpPage37 />} />

      <Route path="/login-page-1" element={<LoginPage1 />} />

      <Route path="/dashboard-2" element={<Dashboard2 />} />

      <Route path="/sign-up-page-2" element={<SignUpPage2 />} />
    </Routes>
  );
}
export default App;
