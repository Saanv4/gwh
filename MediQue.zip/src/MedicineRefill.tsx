import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/MedicineRefill.module.css";

export const MedicineRefill: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.medicineRefillDiv}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <div className={styles.screenshot20220816At1050} />
      <div className={styles.medicineRefillDiv1}>Medicine Refill</div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.imDoneDiv}>I’m done</div>
      <img
        className={styles.screenshot20220816At10501}
        alt=""
        src="screenshot-20220816-at-1050-216@2x.png"
      />
      <div className={styles.doctorPhoneNumber2223333444}>
        Doctor Phone number:2223333444
      </div>
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
    </div>
  );
};
