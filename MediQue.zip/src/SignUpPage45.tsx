import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/SignUpPage45.module.css";

export const SignUpPage45: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.signUpPage4}>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" src="rectangle-10.svg" />
      <div className={styles.rectangleDiv2} />
      <div className={styles.rectangleDiv3} />
      <div className={styles.frequencyOfMedicine3}>
        Frequency of Medicine #3
      </div>
      <div className={styles.ofTotalCapsules}># of Total Capsules</div>
      <b className={styles.loginB}>Login</b>
      <div className={styles.medicine3Div}>Medicine #3</div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <img className={styles.rectangleIcon1} alt="" src="rectangle-16.svg" />
      <b className={styles.nextB}>
        <p className={styles.nextP}>Next</p>
      </b>
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
    </div>
  );
};
