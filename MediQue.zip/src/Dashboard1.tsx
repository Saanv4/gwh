import { FunctionComponent } from "react";
import styles from "./css/Dashboard1.module.css";

export const Dashboard1: FunctionComponent = () => {
  return (
    <div className={styles.dashboard1Div}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <div className={styles.welcomeDiv}>
        <p className={styles.welcomeP}>{`Welcome `}</p>
        <p className={styles.p}>{`  `}</p>
      </div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.rectangleDiv1} />
      <b className={styles.exploreB}>Explore</b>
    </div>
  );
};
