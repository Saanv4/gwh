import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/SignUpPage3.module.css";

export const SignUpPage3: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackText1Click = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  const onRectangleClick = useCallback(() => {
    navigate("/sign-up-page-3");
  }, [navigate]);

  const onRectangle2Click = useCallback(() => {
    navigate("/sign-up-page-31");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/sign-up-page-32");
  }, [navigate]);

  const onText2Click = useCallback(() => {
    navigate("/sign-up-page-33");
  }, [navigate]);

  return (
    <div className={styles.signUpPage3}>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv} />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <div className={styles.rectangleDiv2} />
      <b className={styles.nextB}>
        <p className={styles.nextP}>Next</p>
      </b>
      <div className={styles.backDiv}>Back</div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <div className={styles.rectangleDiv2} />
      <b className={styles.nextB}>
        <p className={styles.nextP}>Next</p>
      </b>
      <div className={styles.backDiv1} onClick={onBackText1Click}>
        Back
      </div>
      <div className={styles.typeOfPatientExampleDiab}>
        Type of Patient (Example: diabetic etc.)
      </div>
      <div className={styles.numberOfMedicines}>Number of Medicines</div>
      <img className={styles.ellipseIcon} alt="" />
      <img
        className={styles.rectangleIcon}
        alt=""
        src="rectangle-23.svg"
        onClick={onRectangleClick}
      />
      <img className={styles.rectangleIcon1} alt="" src="rectangle-24.svg" />
      <img
        className={styles.rectangleIcon2}
        alt=""
        src="rectangle-25.svg"
        onClick={onRectangle2Click}
      />
      <img
        className={styles.rectangleIcon3}
        alt=""
        src="rectangle-26.svg"
        onClick={onRectangle3Click}
      />
      <div className={styles.div}>1</div>
      <div className={styles.div1}>2</div>
      <div className={styles.div2} onClick={onText2Click}>
        3
      </div>
      <div className={styles.div3}>4</div>
    </div>
  );
};
