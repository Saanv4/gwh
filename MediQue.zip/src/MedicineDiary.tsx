import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/MedicineDiary.module.css";

export const MedicineDiary: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.medicineDiaryDiv}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <div className={styles.screenshot20220816At1050} />
      <div className={styles.medicineDiaryDiv1}>Medicine Diary</div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.imDoneDiv}>I’m done</div>
      <div className={styles.rectangleDiv2} />
      <div className={styles.rectangleDiv3} />
      <img
        className={styles.screenshot20220816At10501}
        alt=""
        src="screenshot-20220816-at-1050-214@2x.png"
      />
      <div className={styles.howIFeelToday}>{`How I feel today: `}</div>
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
    </div>
  );
};
