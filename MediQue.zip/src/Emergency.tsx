import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/Emergency.module.css";

export const Emergency: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.emergencyDiv}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <div className={styles.screenshot20220816At1050} />
      <div className={styles.emergencyDiv1}>{`Emergency `}</div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.imDoneDiv}>I’m done</div>
      <img
        className={styles.screenshot20220816At10501}
        alt=""
        src="screenshot-20220816-at-1050-214@2x.png"
      />
      <div className={styles.policeDiv}>Police</div>
      <div className={styles.ambulanceDiv}>Ambulance</div>
      <div className={styles.div}>100</div>
      <div className={styles.div1}>102</div>
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
    </div>
  );
};
