import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./css/MedicineTracker.module.css";

export const MedicineTracker: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBackTextClick = useCallback(() => {
    navigate("/dashboard-2");
  }, [navigate]);

  return (
    <div className={styles.medicineTrackerDiv}>
      <div className={styles.rectangleDiv} />
      <img className={styles.rectangleIcon} alt="" />
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <img className={styles.userIcon} alt="" />
      <div className={styles.screenshot20220816At1050} />
      <div className={styles.medicineTrackerDiv1}>Medicine Tracker</div>
      <img className={styles.ellipseIcon} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon1} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon2} alt="" src="ellipse-2.svg" />
      <img className={styles.ellipseIcon3} alt="" src="ellipse-2.svg" />
      <div className={styles.rectangleDiv1} />
      <div className={styles.imDoneDiv}>I’m done</div>
      <img
        className={styles.screenshot20220816At10501}
        alt=""
        src="screenshot-20220816-at-1050-215@2x.png"
      />
      <div className={styles.backDiv} onClick={onBackTextClick}>
        Back
      </div>
      <div
        className={styles.medicine15DaysLeft5Ca}
      >{`Medicine #1: 5 days left, 5 capsules `}</div>
      <div
        className={styles.medicine210DaysLeft20}
      >{`Medicine #2:  10 days left, 20 capsules `}</div>
      <div
        className={styles.medicine319DayLeft38C}
      >{`Medicine #3:  19 day left, 38 capsules  `}</div>
      <div
        className={styles.medicine40DaysLeftRefi}
      >{`Medicine #4:  0 days left, refill NOW  `}</div>
      <div className={styles.progressBarDiv}>
        <div className={styles.progressDiv}>
          <div className={styles.startDiv} />
          <div className={styles.startDiv} />
        </div>
      </div>
      <div className={styles.progressBarDiv1}>
        <div className={styles.progressDiv1}>
          <div className={styles.startDiv} />
          <div className={styles.startDiv} />
        </div>
      </div>
    </div>
  );
};
