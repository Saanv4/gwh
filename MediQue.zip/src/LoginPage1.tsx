import { FunctionComponent, useCallback, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import styles from "./css/LoginPage1.module.css";

export const LoginPage1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onRectangleLinkClick = useCallback(() => {
    navigate("/dashboard-1");
  }, [navigate]);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div className={styles.loginPage1}>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv1} />
      <div className={styles.passwordDiv}>Password</div>
      <div className={styles.rectangleDiv2} />
      <div className={styles.emailDiv}>Email</div>
      <div className={styles.rectangleDiv3} />
      <div className={styles.youDontHaveAnAccountSi}>
        <span
          className={styles.youDontHave}
        >{`You Don’t have an account ? `}</span>
        <b>Sign up</b>
      </div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <b className={styles.loginB}>Login</b>
      <img className={styles.userIcon} alt="" src="user.svg" />
      <div className={styles.welcomeBackDiv}>{`Welcome back `}</div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <b className={styles.loginB1}>Login</b>
      <div className={styles.rectangleDiv1} />
      <div className={styles.passwordDiv}>Password</div>
      <div className={styles.rectangleDiv2} />
      <div className={styles.emailDiv}>Email</div>
      <div className={styles.rectangleDiv3} />
      <div className={styles.youDontHaveAnAccountSi}>
        <span
          className={styles.youDontHave}
        >{`You Don’t have an account ? `}</span>
        <b>Sign up</b>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <b className={styles.loginB1}>Login</b>
      <div className={styles.rectangleDiv1} />
      <div className={styles.passwordDiv}>Password</div>
      <div className={styles.rectangleDiv2} />
      <div className={styles.emailDiv}>Email</div>
      <div className={styles.rectangleDiv3} />
      <div className={styles.youDontHaveAnAccountSi}>
        <span
          className={styles.youDontHave}
        >{`You Don’t have an account ? `}</span>
        <b>Sign up</b>
      </div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <b className={styles.loginB}>Login</b>
      <img className={styles.userIcon} alt="" src="user.svg" />
      <div className={styles.welcomeBackDiv}>{`Welcome back `}</div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <b className={styles.loginB1}>Login</b>
      <input
        className={styles.rectangleInput}
        type="text"
        required
        data-animate-on-scroll
      />
      <div className={styles.passwordDiv}>Password</div>
      <input
        className={styles.rectangleInput1}
        type="text"
        required
        data-animate-on-scroll
      />
      <div className={styles.emailDiv}>Email</div>
      <Link
        className={styles.rectangleA}
        to="/dashboard-1"
        onClick={onRectangleLinkClick}
      />
      <div className={styles.youDontHaveAnAccountSi}>
        <span
          className={styles.youDontHave}
        >{`You Don’t have an account ? `}</span>
        <b>Sign up</b>
      </div>
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <b className={styles.loginB1}>Login</b>
    </div>
  );
};
