import { FunctionComponent, useEffect } from "react";
import styles from "./css/SignUpPage1.module.css";

export const SignUpPage1: FunctionComponent = () => {
  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div className={styles.signUpPage1}>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv1} />
      <div className={styles.passwordDiv}>Password</div>
      <div className={styles.rectangleDiv2} />
      <div className={styles.haveAnAccountSignIn}>
        <span className={styles.haveAnAccount}>{`Have an account ? `}</span>
        <b>Sign in</b>
      </div>
      <div className={styles.homeIndicatorDiv}>
        <div className={styles.barDiv}>
          <div className={styles.baseDiv} />
        </div>
      </div>
      <b className={styles.signUpB}>Sign up</b>
      <img className={styles.userIcon} alt="" src="user.svg" />
      <img
        className={styles.screenshot20220816At1050}
        alt=""
        src="screenshot-20220816-at-1050-1@2x.png"
      />
      <div className={styles.rectangleDiv3} />
      <b className={styles.continueB}>Continue</b>
      <input
        className={styles.rectangleInput}
        type="text"
        required
        data-animate-on-scroll
      />
      <input
        className={styles.rectangleInput1}
        type="text"
        required
        data-animate-on-scroll
      />
      <input
        className={styles.rectangleInput2}
        type="text"
        required
        data-animate-on-scroll
      />
      <div className={styles.fullNameDiv}>Full Name</div>
      <div className={styles.emailDiv}>Email</div>
      <div className={styles.passwordDiv1}>Password</div>
    </div>
  );
};
